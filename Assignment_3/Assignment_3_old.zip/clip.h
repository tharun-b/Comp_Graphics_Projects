struct GLintPoint
{
	GLint x, y;
};
GLint polygonClipSuthHodg(GLintPoint wMin, GLintPoint wMax, GLint n, GLintPoint * pIn, GLintPoint * pOut);
